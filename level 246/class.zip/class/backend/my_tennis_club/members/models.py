from django.db import models

# Create your models here.
class Member(models.Model):
    firstname = models.CharField(max_length=255)
    lastname = models.CharField(max_length=255)
    age = models.IntegerField(max_length=255)
    join_date = models.DateField(null=True)

    def __str__(self):
        return f"{self.firstname}, {self.lastname}"